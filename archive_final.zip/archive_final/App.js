import * as React from 'react';
import { useState, useEffect } from 'react';
import 'react-native-gesture-handler';
import { Text, View, StyleSheet, TouchableOpacity } from 'react-native';
import { NavigationContainer } from '@react-navigation/native'; //Navigācijas konteineris
import { createStackNavigator } from '@react-navigation/stack'; // Izveido navigācijas steck
import Constants from 'expo-constants';
import Archive from './pages/Archive';
import Item from './pages/Item';
import MyArchives from './pages/MyArchives';
import NewArchive from './pages/NewArchive';
import NewItem from './pages/NewItem';
import Search from './pages/Search';
import Setting from './pages/Setting';
import UserProfile from './pages/UserProfile';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="MyArchives">
        <Stack.Screen
          name="MyArchives"
          component={MyArchives}
          options={({ navigation }) => ({
            title: 'My Archives',
            headerStyle: {
              backgroundColor: '#3d0575',
            },
            headerTintColor: 'white',
            headerTitleAlign: 'center',
            headerRight: () => (
              <View style={{ flexDirection: 'row' }}>
                <TouchableOpacity
                  onPress={() => navigation.navigate('Search')}
                  style={styles.headerRightIcons}>
                  <MaterialCommunityIcons
                    name="magnify"
                    size={30}
                    style={{ color: 'white' }}
                  />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => navigation.navigate('UserProfile')}
                  style={styles.headerRightIcons}>
                  <MaterialCommunityIcons
                    name="account"
                    size={30}
                    style={{ color: 'white' }}
                  />
                </TouchableOpacity>
              </View>
            ),
          })}
        />
        <Stack.Screen
          name="Archive"
          component={Archive}
          options={({ navigation }) => ({
            title: 'Archive',
            headerStyle: {
              backgroundColor: '#3d0575',
            },
            headerTintColor: 'white',
            headerTitleAlign: 'center',
            headerRight: () => (
              <View style={{ flexDirection: 'row' }}>
                <TouchableOpacity
                  onPress={() => navigation.navigate('Search')}
                  style={styles.headerRightIcons}>
                  <MaterialCommunityIcons
                    name="magnify"
                    size={30}
                    style={{ color: 'white' }}
                  />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => navigation.navigate('UserProfile')}
                  style={styles.headerRightIcons}>
                  <MaterialCommunityIcons
                    name="account"
                    size={30}
                    style={{ color: 'white' }}
                  />
                </TouchableOpacity>
              </View>
            ),
          })}
        />
        <Stack.Screen
          name="Setting"
          component={Setting}
          options={({ navigation }) => ({
            title: 'Settings',
            headerStyle: {
              backgroundColor: '#3d0575',
            },
            headerTintColor: 'white',
            headerTitleAlign: 'center',
            headerRight: () => (
              <View style={{ flexDirection: 'row' }}>
                <TouchableOpacity
                  onPress={() => navigation.navigate('Search')}
                  style={styles.headerRightIcons}>
                  <MaterialCommunityIcons
                    name="magnify"
                    size={30}
                    style={{ color: 'white' }}
                  />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => navigation.navigate('MyArchives')}
                  style={styles.headerRightIcons}>
                  <MaterialCommunityIcons
                    name="home-outline"
                    size={30}
                    style={{ color: 'white' }}
                  />
                </TouchableOpacity>
              </View>
            ),
          })}
        />
        <Stack.Screen
          name="UserProfile"
          component={UserProfile}
          options={({ navigation }) => ({
            title: 'User Profile',
            headerStyle: {
              backgroundColor: '#3d0575',
            },
            headerTintColor: 'white',
            headerTitleAlign: 'center',
            headerRight: () => (
              <View style={{ flexDirection: 'row' }}>
                <TouchableOpacity
                  onPress={() => navigation.navigate('Search')}
                  style={styles.headerRightIcons}>
                  <MaterialCommunityIcons
                    name="magnify"
                    size={30}
                    style={{ color: 'white' }}
                  />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => navigation.navigate('MyArchives')}
                  style={styles.headerRightIcons}>
                  <MaterialCommunityIcons
                    name="home-outline"
                    size={30}
                    style={{ color: 'white' }}
                  />
                </TouchableOpacity>
              </View>
            ),
          })}
        />
        <Stack.Screen
          name="NewItem"
          component={NewItem}
          options={({ navigation }) => ({
            title: 'New Item',
            headerStyle: {
              backgroundColor: '#3d0575',
            },
            headerTintColor: 'white',
            headerTitleAlign: 'center',
            headerRight: () => (
              <TouchableOpacity
                onPress={() => navigation.navigate('UserProfile')}
                style={styles.headerRightIcons}>
                <MaterialCommunityIcons
                  name="account"
                  size={30}
                  style={{ color: 'white' }}
                />
              </TouchableOpacity>
            ),
          })}
        />
        <Stack.Screen
          name="Item"
          component={Item}
          options={({ navigation }) => ({
            title: 'Item',
            headerStyle: {
              backgroundColor: '#3d0575',
            },
            headerTintColor: 'white',
            headerTitleAlign: 'center',
            headerRight: () => (
              <View style={{ flexDirection: 'row' }}>
                <TouchableOpacity
                  onPress={() => navigation.navigate('Search')}
                  style={styles.headerRightIcons}>
                  <MaterialCommunityIcons
                    name="magnify"
                    size={30}
                    style={{ color: 'white' }}
                  />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => navigation.navigate('MyArchives')}
                  style={styles.headerRightIcons}>
                  <MaterialCommunityIcons
                    name="home-outline"
                    size={30}
                    style={{ color: 'white' }}
                  />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => navigation.navigate('UserProfile')}
                  style={styles.headerRightIcons}>
                  <MaterialCommunityIcons
                    name="account"
                    size={30}
                    style={{ color: 'white' }}
                  />
                </TouchableOpacity>
              </View>
            ),
          })}
        />
        <Stack.Screen
          name="NewArchive"
          component={NewArchive}
          options={({ navigation }) => ({
            title: 'New Archive',
            headerStyle: {
              backgroundColor: '#3d0575',
            },
            headerTintColor: 'white',
            headerTitleAlign: 'center',
            headerRight: () => (
              <TouchableOpacity
                onPress={() => navigation.navigate('UserProfile')}
                style={styles.headerRightIcons}>
                <MaterialCommunityIcons
                  name="account"
                  size={30}
                  style={{ color: 'white' }}
                />
              </TouchableOpacity>
            ),
          })}
        />
        <Stack.Screen
          name="Search"
          component={Search}
          options={({ navigation }) => ({
            title: 'Search',
            headerStyle: {
              backgroundColor: '#3d0575',
            },
            headerTintColor: 'white',
            headerTitleAlign: 'center',
            headerRight: () => (
              <View style={{ flexDirection: 'row' }}>
                <TouchableOpacity
                  onPress={() => navigation.navigate('MyArchives')}
                  style={styles.headerRightIcons}>
                  <MaterialCommunityIcons
                    name="home-outline"
                    size={30}
                    style={{ color: 'white' }}
                  />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => navigation.navigate('UserProfile')}
                  style={styles.headerRightIcons}>
                  <MaterialCommunityIcons
                    name="account"
                    size={30}
                    style={{ color: 'white' }}
                  />
                </TouchableOpacity>
              </View>
            ),
          })}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
const styles = StyleSheet.create({
  headerRightIcons: {
    marginRight: 20,
  },
});
