import 'react-native-gesture-handler';
import * as React from 'react';
import { useState, useEffect } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
} from 'react-native';
import ActionButton from 'react-native-action-button';
import Icon from 'react-native-vector-icons/Ionicons';

const MyArchives = (props) => {
  const [isLoading, setLoading] = useState(0);
  const [data, setData] = useState([]);
  var bildeLogo = '';
  const getBooks = async () => {
    try {
      const response = await fetch(
        'https://raw.githubusercontent.com/ilauga/testiem/main/Archives.json'
      );
      const result = await response.json();
      setData(result.myarchives);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getBooks();
  }, []);

  const [counter, setCounter] = useState(0);
  return (
    <View style={styles.container}>
      {isLoading ? (
        <ActivityIndicator />
      ) : (
        <FlatList
          data={data}
          keyExtractor={({ id }, index) => id}
          renderItem={({ item }) => (
            <TouchableOpacity
              onPress={() =>
                props.navigation.navigate('Archive', {
                  arName: item.name,
                })
              }>
              <View style={styles.item}>
                <View>
                  {(() => {
                    if (item.name == 'Books') {
                      return (
                        <Image
                          source={require('./Books.jpg')}
                          style={styles.articlePicSmall}
                        />
                      );
                    }
                    return (
                      <Image
                        source={require('./Lego.png')}
                        style={styles.articlePicSmall}
                      />
                    );
                  })()}
                </View>

                <Text style={{ width: '70%' }}>
                  <Text style={styles.archivetitle}>{item.name}</Text>
                </Text>
              </View>
            </TouchableOpacity>
          )}
        />
      )}
      <ActionButton buttonColor="#3d0575">
        <ActionButton.Item
          buttonColor="#3498db"
          title="New Archive"
          onPress={() => props.navigation.navigate('NewArchive', {})}>
          <Icon name="ios-add" style={styles.actionButtonIcon} />
        </ActionButton.Item>
        <ActionButton.Item
          buttonColor="#1abc9c"
          title="New item"
          onPress={() => props.navigation.navigate('NewItem', {})}>
          <Icon name="ios-add" style={styles.actionButtonIcon} />
        </ActionButton.Item>
      </ActionButton>
    </View>
  );
};

export default MyArchives;

const styles = StyleSheet.create({
  archivetitle: {
    fontSize: 26,
    fontWeight: 'bold',
  },
  articlePicSmall: {
    width: 100,
    height: 100,
  },
  item: {
    backgroundColor: '#f9c2ff',
    padding: 5,
    marginVertical: 8,
    marginHorizontal: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  container: {
    flex: 1,
    backgroundColor: 'white',
    padding: 10,
  },
  actionButtonIcon: {
    fontSize: 20,
    height: 22,
    color: 'white',
  },
});
