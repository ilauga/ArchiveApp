import 'react-native-gesture-handler';
import * as React from 'react';
import { useState, useEffect } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { NavigationContainer } from '@react-navigation/native'; //Navigācijas konteineris
import { createStackNavigator } from '@react-navigation/stack'; // Izveido navigācijas steck

const Item = (props) => {
  const [isLoading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [counter, setCounter] = useState(0);
  const arcName = props.route.params.archive;

  if (arcName == 'Legos') {
    return (
      <View style={styles.container}>
        <View style={styles.titlecontainer}>
          <Image
            source={require('./LegoDarthHelmet.jpg')}
            style={styles.itemPicSmall}
          />
        </View>
        <View style={styles.basecontainer}>
          <Text style={styles.itemtitle}>Lego title:</Text>
          <Text style={styles.item}>{props.route.params.title}</Text>
          <Text style={styles.itemtitle}>Model No:</Text>
          <Text style={styles.item}>{props.route.params.setNumber}</Text>
          <Text style={styles.itemtitle}>Series:</Text>
          <Text style={styles.item}>{props.route.params.series}</Text>
          <Text style={styles.itemtitle}>Details count:</Text>
          <Text style={styles.item}>{props.route.params.details}</Text>
          <Text style={styles.itemtitle}>Minifigure count:</Text>
          <Text style={styles.item}>{props.route.params.minifig}</Text>
        </View>
      </View>
    );
  } else
    return (
      <View style={styles.container}>
        <View style={styles.titlecontainer}>
          <Image
            source={require('./BookHamlet.jpg')}
            style={styles.itemPicSmall}
          />
        </View>
        <View style={styles.basecontainer}>
          <Text style={styles.itemtitle}>Book title:</Text>
          <Text style={styles.item}>{props.route.params.title}</Text>
          <Text style={styles.itemtitle}>Author:</Text>
          <Text style={styles.item}>{props.route.params.author}</Text>
          <Text style={styles.itemtitle}>Year released:</Text>
          <Text style={styles.item}>{props.route.params.releaseyear}</Text>
          <Text style={styles.itemtitle}>ISBN:</Text>
          <Text style={styles.item}>{props.route.params.isbn}</Text>
        </View>
      </View>
    );
};

export default Item;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  basecontainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 20,
  },
  itemPicSmall: {
    width: 200,
    height: 240,
  },
  titlecontainer: {
    alignItems: 'center',
    marginTop: 20,
  },
  item: {
    width: '60%',
    fontSize: 20,
    paddingLeft: 10,
  },
  itemtitle: {
    width: '40%',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'right',
  },
});
