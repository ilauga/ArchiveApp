import 'react-native-gesture-handler';
import * as React from 'react';
import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

const Setting = (props) => {
  const [counter, setCounter] = useState(0);
  return (
    <View style={styles.container}>
      <Text style={styles.settingTitle}>Main Settings</Text>
      <TouchableOpacity
        onPress={() => props.navigation.navigate('', {})}
        style={styles.button}>
        <Text style={styles.buttontext}>Change Password</Text>
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => props.navigation.navigate('', {})}
        style={styles.button}>
        <Text style={styles.buttontext}>Change e-mail address</Text>
      </TouchableOpacity>
      <Text style={styles.settingTitle}>Security Settings</Text>
      <TouchableOpacity
        onPress={() => props.navigation.navigate('', {})}
        style={styles.button}>
        <Text style={styles.buttontext}>Enable MFA</Text>
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => props.navigation.navigate('', {})}
        style={styles.button}>
        <Text style={styles.buttontext}>Deactivate Account</Text>
      </TouchableOpacity>
    </View>
  );
};

export default Setting;

const styles = StyleSheet.create({
  buttontext: {
    fontSize: 20,
  },
  button: {
    backgroundColor: '#aca0fa',
    borderRadius: 15,
    paddingVertical: 14,
    marginVertical: 8,
    alignItems: 'center',
  },
  container: {
    marginHorizontal: 60,
  },
  settingTitle: {
    fontSize: 20,
    padding: 8,
    textAlignVertical: 'center',
  },
});
