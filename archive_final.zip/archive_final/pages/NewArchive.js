import 'react-native-gesture-handler';
import * as React from 'react';
import { useState, useEffect } from 'react';
import {
  Alert,
  TextInput,
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import DropDownPicker from 'react-native-dropdown-picker';

let text = '';

const NewArchive = (props) => {
  const [value, onChangeText] = React.useState('Enter value...');

  function textChangeHandler(event) {
    onChangeText(event.target.value);
    text = event.target.value;
  }

  const createInfoAlert = () =>
    Alert.alert('Message', 'Are you sure you want to create new Archive?', [
      {
        text: 'Cancel',
        onPress: () => props.navigation.navigate('NewArchive', {}),
        style: 'cancel',
      },
      {
        text: 'OK',
        onPress: () => props.navigation.navigate('MyArchives', {}),
      },
    ]);

  return (
    <View style={styles.container}>
      <Text style={styles.textlabel}>Archive title:</Text>
      <TextInput
        style={styles.textinput}
        onChange={textChangeHandler}
        value={value}
      />
      <Text style={styles.textlabel}>Archive item type:</Text>
      <DropDownPicker
        items={[
          { label: 'Lego', value: 'leg' },
          { label: 'Books', value: 'boo' },
          { label: 'Coins', value: 'cns' },
          { label: 'Playing Cards', value: 'plc' },
          { label: 'Other', value: 'msc' },
        ]}
        defaultIndex={1}
        containerStyle={{ height: 40 }}
        onChangeItem={(item) => console.log(item.label, item.value)}
      />
      <TouchableOpacity onPress={createInfoAlert} style={styles.button}>
        <Text style={styles.buttontext}>Create Archive</Text>
      </TouchableOpacity>
    </View>
  );
};

export default NewArchive;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    margin: 25,
  },
  textinput: {
    height: 40,
    borderColor: 'black',
    borderWidth: 1,
    color: '#595959',
    fontSize: 20,
    padding: 7,
    marginHorizontal: 5,
    textAlign: 'center',
  },
  textlabel: {
    fontSize: 20,
    padding: 7,
  },
  buttontext: {
    fontSize: 20,
  },
  button: {
    backgroundColor: '#aca0fa',
    borderRadius: 15,
    paddingVertical: 14,
    marginVertical: 30,
    marginHorizontal: 60,
    alignItems: 'center',
  },
});
