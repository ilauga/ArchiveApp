// In App.js in a new project
import 'react-native-gesture-handler';
import * as React from 'react';
import { useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { SearchBar } from 'react-native-elements';

const Search = (props) => {
  const [isLoading, setLoading] = useState(true);
  this.state = { search: '' };
  this.arrayholder = [];
  const [data, setData] = useState([]);
  const getData = async () => {
    try {
      const response = await fetch(
        'https://raw.githubusercontent.com/ilauga/testiem/main/Books.json'
      );
      const result = await response.json();
      setData(result.books);
      this.arrayholder = result;
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  search = (text) => {
    console.log(text);
  };
  clear = () => {
    this.search.clear();
  };

  return (
    <View style={styles.viewStyle}>
      <SearchBar
        placeholder="Type Here..."
        onChangeText={this.updateSearch}
        value={search}
        platform="light"
      />
    </View>
  );
};

export default Search;

const styles = StyleSheet.create({
  viewStyle: {
    justifyContent: 'center',
    backgroundColor: 'white',
  },
});
