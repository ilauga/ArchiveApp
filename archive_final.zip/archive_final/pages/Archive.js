import 'react-native-gesture-handler';
import * as React from 'react';
import { useState, useEffect, Component } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native'; //Navigācijas konteineris
import { createStackNavigator } from '@react-navigation/stack'; // Izveido navigācijas steck
import ActionButton from 'react-native-action-button';
import Icon from 'react-native-vector-icons/Ionicons';

const MyArchives = (props) => {
  const [isLoading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const testing = props.route.params.arName;
  const archiveName =
    'https://raw.githubusercontent.com/ilauga/testiem/main/' +
    testing +
    '.json';

  const getData = async () => {
    try {
      const response = await fetch(archiveName);
      const result = await response.json();
      if (testing == 'Legos') {
        setData(result.legos);
      } else setData(result.books);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getData();
  });

  const [counter, setCounter] = useState(0);
  if (testing == 'Legos') {
    return (
      <View style={styles.container}>
        {isLoading ? (
          <ActivityIndicator />
        ) : (
          <FlatList
            data={data}
            keyExtractor={({ id }, index) => id}
            renderItem={({ item }) => (
              <TouchableOpacity
                onPress={() =>
                  props.navigation.navigate('Item', {
                    title: item.title,
                    series: item.series,
                    details: item.details,
                    setNumber: item.number,
                    minifig: item.minifigures,
                    archive: testing,
                  })
                }>
                <View style={styles.item}>
                  <Text style={{ width: '70%' }}>
                    <Text style={styles.articletitle}>
                      {item.title}
                      <Text style={styles.articleauthor}>
                        {'\n'} {'\n'}
                        Set #{item.number}
                      </Text>
                      <Text style={styles.articleauthor}>
                        {'\n'} {'\n'}
                        Lego series: {item.series}
                      </Text>
                    </Text>
                  </Text>
                </View>
              </TouchableOpacity>
            )}
          />
        )}
        <ActionButton buttonColor="#3d0575">
          <ActionButton.Item
            buttonColor="#1abc9c"
            title="New item"
            onPress={() => props.navigation.navigate('NewItem', {})}>
            <Icon name="ios-add" style={styles.actionButtonIcon} />
          </ActionButton.Item>
        </ActionButton>
      </View>
    );
  } else
    return (
      <View style={styles.container}>
        {isLoading ? (
          <ActivityIndicator />
        ) : (
          <FlatList
            data={data}
            keyExtractor={({ id }, index) => id}
            renderItem={({ item }) => (
              <TouchableOpacity
                onPress={() =>
                  props.navigation.navigate('Item', {
                    title: item.title,
                    author: item.author,
                    releaseyear: item.releaseYear,
                    isbn: item.ISBN,
                    archive: testing,
                  })
                }>
                <View style={styles.item}>
                  <Text style={{ width: '70%' }}>
                    <Text style={styles.articletitle}>
                      {item.title}
                      <Text style={styles.articleauthor}>
                        {'\n'} {'\n'}
                        by {item.author}
                        {item.details}
                      </Text>
                    </Text>
                  </Text>
                </View>
              </TouchableOpacity>
            )}
          />
        )}
        <ActionButton buttonColor="#3d0575">
          <ActionButton.Item
            buttonColor="#1abc9c"
            title="New item"
            onPress={() => props.navigation.navigate('NewItem', {})}>
            <Icon name="ios-add" style={styles.actionButtonIcon} />
          </ActionButton.Item>
        </ActionButton>
      </View>
    );
};

export default MyArchives;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  articletitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  articleauthor: {
    alignItems: 'right',
    fontSize: 15,
    fontWeight: 'normal',
  },
  item: {
    backgroundColor: '#f9c2ff',
    padding: 5,
    marginVertical: 8,
    marginHorizontal: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});
