import 'react-native-gesture-handler';
import * as React from 'react';
import { useState, useEffect } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';

const UserProfile = (props) => {
  const [counter, setCounter] = useState(0);
  return (
    <View style={styles.container}>
      <View style={styles.titleContainer}>
        <Image
          source={require('./UserPic.jpg')}
          style={styles.circleImageLayout}
        />
        <Text style={styles.textIntro}>Ieva Lauga</Text>
      </View>
      <Text style={styles.profileInfo}>E-mail: test@test.lv</Text>
      <Text style={styles.profileInfo}>No of Archives: 2</Text>
      <TouchableOpacity
        onPress={() => props.navigation.navigate('Setting', {})}
        style={styles.button}>
        <Text style={styles.buttontext}>Settings</Text>
      </TouchableOpacity>
    </View>
  );
};

export default UserProfile;

const styles = StyleSheet.create({
  container: {
    padding: 8,
  },
  titleContainer: {
    alignItems: 'center',
  },
  textIntro: {
    fontSize: 22,
    padding: 8,
    color: '#3d0575',
    textAlignVertical: 'center',
  },
  profileInfo: {
    marginHorizontal: 25,
    marginBottom: 15,
    fontSize: 18,
    textAlign: 'left',
  },
  circleImageLayout: {
    width: 200,
    height: 200,
    borderRadius: 200 / 2,
    marginTop: 20,
    padding: 8,
  },
  buttontext: {
    fontSize: 20,
  },
  button: {
    backgroundColor: '#aca0fa',
    borderRadius: 15,
    paddingVertical: 14,
    marginVertical: 8,
    marginHorizontal: 60,
    alignItems: 'center',
  },
});
