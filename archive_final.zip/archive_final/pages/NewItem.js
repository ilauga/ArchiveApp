// In App.js in a new project
import 'react-native-gesture-handler';
import * as React from 'react';
import { useState, useEffect } from 'react';
import {
  Alert,
  View,
  TextInput,
  Text,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import DropDownPicker from 'react-native-dropdown-picker';

const NewItem = (props) => {
  const [counter, setCounter] = useState(0);
  const [value, onChangeText] = React.useState('Enter value...');
  var text = '';
  function textChangeHandler(event) {
    onChangeText(event.target.value);
    text = event.target.value;
  }

  const createInfoAlert = () =>
    Alert.alert('Message', 'Are you sure you want to create new item?', [
      {
        text: 'Cancel',
        onPress: () => props.navigation.navigate('NewItem', {}),
        style: 'cancel',
      },
      {
        text: 'OK',
        onPress: () => props.navigation.navigate('MyArchives', {}),
      },
    ]);

  return (
    <View style={styles.container}>
      <Text style={styles.containerItemFirst}>Item type:</Text>
      <DropDownPicker
        items={[
          { label: 'Lego', value: 'leg' },
          { label: 'Book', value: 'boo' },
          { label: 'Coin', value: 'cns' },
          { label: 'Playing Cards', value: 'plc' },
          { label: 'Other', value: 'msc' },
        ]}
        defaultIndex={1}
        onChangeItem={(item) => console.log(item.label, item.value)}
      />
      <Text style={styles.containerItems}>Choose Archive</Text>
      <DropDownPicker
        items={[
          { label: 'Legos', value: 'leg' },
          { label: 'Books', value: 'boo' },
        ]}
        defaultIndex={1}
        onChangeItem={(item) => console.log(item.label, item.value)}
      />
      <Text style={styles.textlabel}>Item title:</Text>
      <TextInput
        style={styles.textinput}
        onChange={textChangeHandler}
        value={value}
      />
      <TouchableOpacity onPress={createInfoAlert} style={styles.button}>
        <Text style={styles.buttontext}>Create Item</Text>
      </TouchableOpacity>
    </View>
  );
};

export default NewItem;

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#ecf0f1',
    margin: 20,
    padding: 20,
  },
  containerItemFirst: {
    fontSize: 20,
  },
  containerItems: {
    fontSize: 20,
    marginTop: 20,
  },
  buttontext: {
    fontSize: 20,
  },
  button: {
    backgroundColor: '#aca0fa',
    borderRadius: 15,
    paddingVertical: 14,
    marginVertical: 30,
    marginHorizontal: 60,
    alignItems: 'center',
  },
  textinput: {
    height: 40,
    borderColor: 'black',
    borderWidth: 1,
    color: '#595959',
    fontSize: 20,
    padding: 7,
    marginHorizontal: 5,
    textAlign: 'center',
  },
  textlabel: {
    fontSize: 20,
    padding: 7,
  },
});
